def getCry():
    print('123')